package com.ratelimiter.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demothrottling2Application {

	public static void main(String[] args) {
		SpringApplication.run(Demothrottling2Application.class, args);
	}

}
