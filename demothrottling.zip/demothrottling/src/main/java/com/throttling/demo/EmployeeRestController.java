package com.throttling.demo;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.util.concurrent.RateLimiter;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor

public class EmployeeRestController {

	
	private final  RateLimiter rateLimiter;
	
	@GetMapping(value = "/getemp")
	public ResponseEntity<?> getEmp() {
		boolean getStatus=rateLimiter.tryAcquire();
		System.out.println(java.time.LocalTime.now() + " HOW MANY REQUEST IS :::" +getStatus);
		if(getStatus) {
			return new ResponseEntity<EmpolyeeModel>(new EmpolyeeModel("abc", "xyz"),
					HttpStatus.OK);
		}
		else {
			return new ResponseEntity<String>("TOO_MANY_REQUESTS",HttpStatus.TOO_MANY_REQUESTS);
		}
			
	}

}
