package com.throttling.demo;

import java.time.Duration;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.google.common.util.concurrent.RateLimiter;

@Component
public class ThrottlingUtils {
	
	
	@Bean
	public RateLimiter rateLimiter() {
 		return RateLimiter.create(5.0);
		//return RateLimiter.create(5.0, Duration.ofMillis(5)); // 
		
	}

}
