package com.throttling.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemothrottlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemothrottlingApplication.class, args);
	}

}
